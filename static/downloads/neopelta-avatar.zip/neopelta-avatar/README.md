# Avatar Pixel Art - Ronan PLUTA FONTAINE

## 📁 Archive Content

This archive contains the source files and exports of the pixel art avatar created for Ronan PLUTA FONTAINE's portfolio (https://www.neopelta.fr).

### 🎨 Aseprite Source Files (.ase)
- `avatar_default.ase` - Neutral avatar (normal expression)
- `avatar_speak.ase` - Speaking avatar (finger raised)
- `avatar-og.ase` - Open Graph version for social networks

### 🖼️ PNG Exports
- `avatar_default.png`
- `avatar_default_bg.png` - Version with background #e3d5b4 and border #472b34
- `avatar_speak.png`
- `avatar_speak_bg.png` - Version with background #e3d5b4 and border #472b34
- `avatar-og.png` - Open Graph version (1200x630px)

### 🖼️ WebP Exports
- `avatar_default.webp`
- `avatar_default_bg.webp` - Version with background #e3d5b4 and border #472b34
- `avatar_speak.webp`
- `avatar_speak_bg.webp` - Version with background #e3d5b4 and border #472b34
- `avatar-og.webp` - Open Graph version (1200x630px)

### 🖼️ SVG Exports
- `avatar_default.svg`
- `avatar_speak.svg`

## 🛠️ Software Used

**Aseprite** - Software for pixel art creation and 2D animation
- Official website: https://www.aseprite.org/
- Version used: 1.3.14

## 🔄 Versions and Variants

### avatar_default
- Neutral expression
- Usage: Main avatar, navigation, presentation

### avatar_speak
- Finger raised
- Usage: Interactive sections, testimonials, info-notes

### avatar-og (Open Graph)
- Format adapted for social networks
- Dimensions optimized for Facebook, Twitter, LinkedIn
- Integrated in site metadata

## 📝 Creation Notes

### Artistic Process
1. **Photo** - Using a photo as reference
2. **Pixel art** - Creation pixel by pixel in Aseprite

## 🔧 How to Modify Files

### With Aseprite
1. Open the `.ase`/`.aseprite` file in Aseprite
2. Modify according to your needs
3. Export: `File > Export > Export As...`
4. Choose desired dimensions

## 📜 License and Usage

### Copyright
© 2025 Ronan PLUTA FONTAINE - All rights reserved

### Authorized Usage
- **Personal consultation**: Free
- **Commercial use**: Prohibited without authorization

### Attribution
If you use these files for educational or demonstration purposes, please credit:
"Pixel art avatar by Ronan PLUTA FONTAINE - https://www.neopelta.fr"

## 📞 Contact

For any questions regarding these files:
- **Portfolio**: https://www.neopelta.fr
- **LinkedIn**: https://linkedin.com/in/ronan-pluta-fontaine
- **GitHub**: https://github.com/Neopelta

## 🔗 Additional Resources

### Learn Aseprite
- [Official Aseprite Tutorials](https://www.aseprite.org/docs/)

---

**Author**: Ronan PLUTA FONTAINE  
**Website**: https://www.neopelta.fr